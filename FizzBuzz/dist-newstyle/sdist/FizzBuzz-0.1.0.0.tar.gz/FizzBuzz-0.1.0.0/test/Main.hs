-- Archivo: test/Main.hs
module Main where

import Test.Tasty
import Test.Tasty.HUnit
import FizzBuzz (fizzBuzz, esPrimo, numeroEnPalabras) -- Importamos la función desde FizzBuzz

main :: IO ()
main = defaultMain tests

tests :: TestTree
tests = testGroup "Tests"
  [ testCase "FizzBuzz test" $
      assertEqual "Should return FizzBuzz!" "FizzBuzz!" (fizzBuzz 11),
    testCase "Number to words test" $
      assertEqual "Should return \"once\"" "once" (numeroEnPalabras 11),
    testCase "Prime test" $
      assertEqual "Should return FizzBuzz!" "FizzBuzz!" (fizzBuzz 13)
  ]
